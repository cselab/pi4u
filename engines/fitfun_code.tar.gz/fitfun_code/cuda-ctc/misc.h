//
//  misc.h
//  CTC
//
//  Created by Dmitry Alexeev on 13/11/14.
//  Copyright (c) 2014 Dmitry Alexeev. All rights reserved.
//

#pragma once

typedef float real;