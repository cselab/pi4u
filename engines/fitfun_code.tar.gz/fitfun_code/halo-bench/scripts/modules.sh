module load PrgEnv-gnu 
module load cudatoolkit/5.5.20-1.0501.7945.8.2
