#pragma once

void scan(const unsigned char * const input, const int size, cudaStream_t stream, uint * const output);

